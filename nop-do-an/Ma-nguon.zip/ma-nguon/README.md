# Mã nguồn

Mã nguồn của đề tài Nhận dạng chữ viết tay tiếng Việt trên thiết bị cảm ứng. Hệ thống nhận dạng chữ viết tay theo dòng, chạy không cần mạng trên điện thoại Android và cho phép ngắt dòng khi viết.

## 1. Cấu trúc

Bảng 1 ghi vai trò của từng thư mục.

Bảng 1: Các thư mục của mã nguồn

| Thư mục | Nội dung |
| --- | --- |
| `android/` | Ứng dụng Android viết bằng Kotlin: khung viết, lớp ghép đoạn, bước vẽ ảnh, chạy mô hình bằng LiteRT, bộ giải mã beam search với n-gram âm tiết và n-gram ký tự, phép đối chiếu với bản Python |
| `android/app/src/main/assets/` | Các tệp đi kèm ứng dụng: `model.tflite` là bản float16 của mô hình `m1l_rr_e100`, `lm.bin` là n-gram âm tiết, `clm.bin` là n-gram ký tự, `chars.txt` là bộ ký tự, `params.txt` ghi α, β, độ dày nét, trọng số và điểm thưởng của n-gram ký tự |
| `android/app/src/androidTest/` | Bài đo trên điện thoại hoặc máy ảo: chạy cả luồng của ứng dụng và chạy ML Kit trên nét của tập tự thu. Tệp nét của tập tự thu không nằm trong gói này |
| `training/` | Mã Python: đọc dữ liệu VNOnDB, mô hình, huấn luyện, giải mã, mô hình ngôn ngữ, lớp ghép đoạn, bộ mô phỏng dòng ngắt, chuyển đổi sang LiteRT và đánh giá |
| `tools/thu-net/` | Công cụ thu nét chạy trên trình duyệt điện thoại, câu đề, quy trình thu và mẫu phiếu đồng ý |
| `tools/check_docs.py` | Mã kiểm tra tài liệu phát triển |

## 2. Dựng và cài ứng dụng

Cần Android SDK và JDK 17. Khai báo đường dẫn Android SDK trong `android/local.properties` bằng dòng `sdk.dir=...`, hoặc đặt biến môi trường `ANDROID_HOME`. Sau đó, trong thư mục `android/`:

1. Chạy `gradlew assembleRelease` trên Windows, hoặc `./gradlew assembleRelease` trên Linux.
2. Cài tệp `app/build/outputs/apk/release/app-release.apk` lên điện thoại bằng lệnh `adb install -r app/build/outputs/apk/release/app-release.apk`.

Bản release chỉ chứa thư viện cho điện thoại ARM 64 bit, không chứa ML Kit và không cần quyền mạng. Để chạy trên máy ảo x86_64, dùng `gradlew assembleDebug`. Bản debug có thêm ML Kit và quyền mạng, chỉ để chạy bài đo so sánh. Lệnh `gradlew test` chạy phép đối chiếu bản Kotlin với bản Python.

## 3. Môi trường Python

Mã trong `training/` chạy với Python 3.12 trên Ubuntu, với các thư viện TensorFlow 2.21.0, Keras 3.15.1, tf-keras 2.21.0, NumPy 2.5.4, Pillow 13.0.0 và scikit-image 0.26.0. Mỗi tệp có phần mô tả ở đầu tệp. Các chú thích nhắc đến `docs/` là tài liệu phát triển của đề tài, không nằm trong gói này, và nội dung tương ứng đã được đưa vào báo cáo. Các bước chính:

1. `train.py` huấn luyện mô hình trên ảnh dòng của VNOnDB.
2. `build_ngram.py` dựng mô hình ngôn ngữ n-gram âm tiết, `tune_decoder.py` chỉnh α và β.
3. `build_char_ngram.py` dựng n-gram ký tự, `eval_char_lm.py` chỉnh trọng số và đo bộ giải mã có n-gram ký tự trong `decoder_char.py`.
4. `export_tflite.py` chuyển mô hình sang LiteRT, `export_assets.py` tạo các tệp đi kèm ứng dụng.
5. `eval_deployed.py` đo trên tập kiểm định và tập kiểm thử VNOnDB, `eval_selfcollected.py` đo trên các tệp nét viết tự thu.
6. `export_bench.py` ghi nét của tập tự thu cho bài đo trên thiết bị, `eval_mlkit.py` chấm kết quả của ML Kit và của ứng dụng.

Dữ liệu VNOnDB và tập dữ liệu tự thu không nằm trong mã nguồn.
