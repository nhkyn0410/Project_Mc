# Tập dữ liệu tự thu

Thư mục này chứa nét viết tay tiếng Việt do đề tài tự thu trên điện thoại, từ ngày 09/11/2026 đến ngày 19/11/2026, bằng công cụ thu nét chạy trên trình duyệt (`tools/thu-net/` trong mã nguồn). Dữ liệu được dùng ở Chương 3 và Chương 4 của báo cáo. Bộ ảnh VNOnDB dùng để huấn luyện là dữ liệu công khai, nên không nằm ở đây.

## 1. Ẩn danh

Mỗi người viết chỉ được ghi bằng mã: K01, P01 và V03 đến V08 ở các buổi thử, mã ngẫu nhiên dạng NV-XXXX ở các đợt thu chính thức. Các tệp không chứa họ tên người viết. Phiếu đồng ý có họ tên nên không đi kèm thư mục này. Mẫu phiếu trống nằm ở `tools/thu-net/phieu-dong-y.md` trong mã nguồn.

## 2. Các thư mục

Bảng 1 ghi nội dung của từng thư mục. Dòng liền là dòng viết trọn trên một dải, dòng ngắt là dòng được viết thành nhiều hàng.

Bảng 1: Các thư mục của tập dữ liệu

| Thư mục | Nội dung | Số buổi | Số dòng | Dòng chép khác đề | Dùng trong báo cáo |
| --- | --- | --- | --- | --- | --- |
| `1-buoi-thu/but-dot-1/` | Buổi thử ngày 09/11/2026, viết bằng bút S Pen, mã K01 và P01 | 2 | 26, gồm 20 dòng ngắt và 6 dòng liền | 8 | Mục 4.4 |
| `1-buoi-thu/but-dot-2/` | Buổi thử ngày 10/11/2026, viết bằng bút S Pen, mã V03 đến V06 | 4 | 60, gồm 40 dòng ngắt và 20 dòng liền | 7 | Mục 4.4 |
| `1-buoi-thu/ngon-tay/` | Buổi thử ngày 11/11/2026, viết bằng ngón tay trên iPhone, 3 buổi của 2 người, mã V07 và V08 | 3 | 50, gồm 30 dòng ngắt và 20 dòng liền | 5, đánh dấu ngay trong tệp | Mục 4.5 |
| `2-nhom-chinh/` | Nhóm chỉnh, viết bằng ngón tay trên điện thoại, thu từ ngày 12/11/2026 đến ngày 16/11/2026 | 9 | 180, gồm 90 dòng ngắt và 90 dòng liền | 12 | Mục 4.5 |
| `3-tap-danh-gia/` | Tập đánh giá, 19 người viết bằng ngón tay trên điện thoại của mình, thu từ ngày 17/11/2026 đến ngày 19/11/2026 | 19 | 380, gồm 190 dòng ngắt và 190 dòng liền | 42 | Mục 4.6 và mục 4.7 |
| `4-de-rieng/nhom-chinh/` | Các buổi nhóm chỉnh không đủ điều kiện, lý do ghi trong `ly-do.txt` | 3 | 60 | Không có tệp rà soát | Không dùng |
| `4-de-rieng/nhom-kiem-thu/` | Các buổi nhóm kiểm thử của đợt thu đầu, lý do ghi trong `ly-do.txt` | 4 | 80 | 5 | Không dùng |

Tổng cộng có 44 buổi và 836 dòng. Tệp gốc của P01 bị cắt cụt khi xuất, nên `P01.json` là bản sửa giữ 11 dòng đầu đọc được, ghi chú trong trường `repairNote`.

## 3. Thứ tự viết

Ở các buổi thử viết bằng bút, mỗi người viết 15 câu: 10 câu đầu thành dòng ngắt với hai cỡ hàng kẻ, 5 câu sau thành dòng liền. Ở các đợt thu chính thức, mỗi người viết 20 câu đã khóa sẵn với hàng kẻ cao 12 mm. Nhóm A viết 10 câu đầu thành dòng liền và 10 câu sau thành dòng ngắt, nhóm B làm ngược lại, để mỗi câu có cả hai cách viết.

## 4. Định dạng tệp

Mỗi tệp `.json` là một buổi viết, hoặc một gói có dạng `{"schema", "sessions": [...]}` chứa nhiều buổi, như `K01.json`, `buoi-thu-2.json`, `ngon-tay-1.json` và `NV-8ZS8.json`. Các trường chính của một buổi:

- `participant`: mã người viết.
- `group`: nhóm A hoặc nhóm B theo mục 3.
- `input`: `pen` là bút, `touch` là ngón tay.
- `protocol`: `pilot` là buổi thử, `official` là đợt thu chính thức. Trường `cohort` ghi `chinh` cho nhóm chỉnh và `kiem-thu` cho nhóm kiểm thử.
- `device`: đời máy, chuỗi trình duyệt, kích thước màn hình và `pxPerMm`, tức số điểm ảnh CSS trên mỗi milimét.
- `lines`: danh sách các dòng.

Các trường chính của một dòng:

- `index`: thứ tự dòng trong buổi, đếm từ 0.
- `condition`: `continuous` là dòng liền, `broken` là dòng ngắt.
- `text`: câu đề người viết phải chép.
- `rowHeightMm`: chiều cao hàng kẻ của dòng ngắt.
- `strokes`: danh sách nét. Mỗi nét có `pointerType`, độ lệch cuộn khung `view` và `points`. Mỗi điểm có dạng `[x, y, t, lực nhấn, độ nghiêng x, độ nghiêng y]`, trong đó x và y tính bằng điểm ảnh CSS, t tính bằng mili giây kể từ điểm đầu tiên của dòng. Chia x và y cho `device.pxPerMm` để đổi sang milimét.
- `review`: đánh dấu của người thu, gồm kết luận chép đúng hay chép khác đề.

## 5. Tệp rà soát

Người thu không đánh dấu được hết các dòng chép khác đề, nên đề tài rà soát lại bằng mắt trên ảnh vẽ từ nét gốc. Kết quả nằm trong `review.json` của từng thư mục. Mỗi mục có mã người viết, `index` và một trong hai cờ:

- `miscopied`: dòng viết khác câu đề, bị loại khỏi mọi phép đo.
- `stray`: dòng có nét lạc do chạm nhầm, chỉ để ghi nhận, vẫn được dùng.

Mã `training/eval_selfcollected.py` trong mã nguồn đọc trực tiếp các tệp này, với tùy chọn `--review` để loại các dòng chép khác đề.
